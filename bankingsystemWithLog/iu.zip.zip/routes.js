'use strict';
/*Contains Route js*/
var framework = require('./framework/framework.js'),
    transactionsController = require('./controllers/transactions.js'),
    updateController=require('./controllers/updateinfo.js'),
    requestsController=require('./controllers/requests.js'),
    logger = framework.getLogger(),
    fs = require('fs'),
    bodyParser = require('body-parser');
    var fs = require('fs');
    PDFDocument = require('pdfkit');
module.exports = function (app) {


    app.post('/transactionsiu', function (req,res) {
      transactionsController.createTransaction(req, res);

    });
    app.get('/getUserInfo', function (req, res) {
        console.log("Reached Here1");
        updateController.getUserInfo(req, res);
    });
    app.post('/updateUserInfo', function (req, res) {
        console.log("PostUpdateUserInfo");
        updateController.updateUserInfo(req, res);
    });
    app.get('/printLog', function (req, res) {

      var  doc;
      doc = new PDFDocument;
      console.log("HEre");
      doc.pipe(fs.createWriteStream('output.pdf'));
      doc.fontSize(15).text('Wally Gator !', 50, 50);
// Set the paragraph width and align direction
      doc.text('Wally Gator is a swinging alligator in the swamp. He\'s the greatest percolator when he really starts to romp. There has never been a greater operator in the swamp. See ya later, Wally Gator.', {
    width: 410,
    align: 'left'
});
// PDF Creation logic goes here
      doc.end();
      res.send(doc)


    });
    app.post('/createiuaccount', function (req, res) {
        console.log("CreateNewAccount");
        updateController.createNewAccount(req, res);
    });
    app.get('/requests', function (req, res) {
        requestsController.getRequests(req, res);
    });
    app.post('/requests/:id/accept', function (req, res) {
        requestsController.acceptRequest(req, res);
    });
    app.post('/requests/:id/reject', function (req, res) {
        requestsController.rejectRequest(req, res);
    });
    app.post('/umail', function (req, res) {
        updateController.updateEmail(req, res);
    });
    app.post('/upwd', function (req, res) {
        updateController.updatePwd(req, res);
    });
    app.post('/uphno', function (req, res) {
        updateController.updatePhno(req, res);
    });
    app.post('/uaddr', function (req, res) {
        updateController.updateAddr(req, res);
    });
  app.post('/logoutiu', function (req, res, next) {
    if(req.session.ipadd==req.connection.remoteAddress){


req.session.destroy(function(err) {
 res.render('../public/home.ejs',{

          });

});
}
});




    app.all('*.html', function (req, res) {
         console.log(req.url);
         var out = fs.readFileSync("templates" + req.url);
         res.set('content-type', 'text/html');
         res.send(out);

     });


};
