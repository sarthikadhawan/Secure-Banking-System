/** Transactions **/

var framework = require('../framework/framework.js');
var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'a',
  database : 'bankingsystem'
});


connection.connect(function(err){
if(!err) {
    console.log("Database is connected ... nn");
} else {
    console.log("Error connecting database ... nn");
}
});

function chceckAmountAndUpdateTransaction(body, res) {

  var values = [parseInt(req.sanitize(body.debitAccount))];
  console.log(req.sanitize(body.debitAccount)+"DebitAccount");
  connection.query('select * from account where ID =?',values, function(err, rows, fields) {
    if (!err){
      console.log("reachedinside");
      if(parseInt(req.sanitize(body.amount)) < rows[0].Balance){
        createTransactionSuccess(body,res);
      }else{
        framework.renderPage(res, "error", { "message" : "Insufficient balance" });
      }
  }
    else{
      console.log("Error in check balance");
      console.log('Error while performing Query.' + err);
    }
    });

}

function createTransaction(req, res) {
	console.log("request body : " + JSON.stringify(req.body));
	var body = req.body;
	chceckAmountAndUpdateTransaction(body,res);
  res.render('../public/frontpageiu.ejs',{userid:req.session.userid,
  usertype:req.session.usertype,
  sessionid:req.session.sessionid,
  useraadhar:req.session.useraadhar});
}

function createTransactionSuccess(body, res){
  var values = [req.sanitize(body.creditAccount),req.sanitize(body.debitAccount),req.sanitize(body.creditAadharNo),req.sanitize(body.debitAadharNo),req.sanitize(body.amount),0];
	connection.query('insert into transaction(CreditAccount, DebitAccount, CreditAadharNo, DebitAadharNo, Amount, Status) values(?,?,?,?,?,?)',values, function(err, rows, fields) {
	  if (!err){
	    console.log('The solution is: '+JSON.stringify(rows));
      console.log('is id ' + rows.insertId);
      if(req.sanitize(body.amount) < 25000){
          addRequest("transactionreqre",rows.insertId);
      }else if(req.sanitize(body.amount) >= 25000 && req.sanitize(body.amount) < 50000){
            addRequest("transactionreqsa",rows.insertId);
      }else if(req.sanitize(body.amount) >= 50000){
            addRequest("transactionreqsm",rows.insertId);
      }
	}
	  else{
      console.log("Error in createTransactionSuccess");
	    console.log('Error while performing Query.' + err);
		}
	  });
    res.end();
}

function addRequest(tableName, transactionID){
  values = [transactionID];
  connection.query('insert into '+tableName +'(transactionID) values(?)',values, function(err, rows, fields) {
	  if (!err){
        console.log("succefully inserted entry into " + tableName + " table");

	}
	  else{
      console.log("Error in Add request");
	    console.log('Error while performing Query.' + err);
		}
	  });
}

function updateAccountBalance(amount, account){
  var values = [amount,account]
  connection.query('update Account set Balance = Balance+? where ID = ?',values, function(err, rows, fields) {
	  if (!err){
	    console.log('The solution is: '+JSON.stringify(rows));
	}
	  else{
	    console.log('Error while performing Query.' + err);

		}
	  });
}


exports.createTransaction=createTransaction;
